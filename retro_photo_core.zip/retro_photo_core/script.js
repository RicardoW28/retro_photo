const upload = document.getElementById("upload");
const preview = document.getElementById("preview");
const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

upload.addEventListener("change", () => {
  const file = upload.files[0];
  if (file) {
    preview.src = URL.createObjectURL(file);
    preview.style.display = "block";
    preview.classList.remove("vhs-effect"); // remove overlay se trocar imagem
  }
});

function aplicarFiltro(estilo) {
  // remove overlay VHS se mudar de filtro
  preview.classList.remove("vhs-effect");

  switch(estilo) {
    case 'sony2007':
      preview.style.filter = "contrast(53%) brightness(54%) saturate(144%) drop-shadow(0 0 1px #000)";
      break;
    case 'anos90':
      preview.style.filter = "contrast(120%) saturate(110%) brightness(95%)";
      break;
    case 'vhs':
      // VHS com linhas e leve borrado
      preview.style.filter = "grayscale(25%) contrast(75%) brightness(92%) blur(0.7px) saturate(110%)";
      preview.classList.add("vhs-effect");
      break;
    case 'dreamcore':
      preview.style.filter = "saturate(150%) brightness(110%) contrast(90%)";
      break;
    case 'anos80':
      preview.style.filter = "brightness(110%) contrast(85%) saturate(180%) hue-rotate(300deg) drop-shadow(0 0 3px #ff80ff)";
      break;
    case 'vintage':
      preview.style.filter = "brightness(125%) contrast(70%) saturate(130%) sepia(30%) hue-rotate(10deg) drop-shadow(0 0 1px #000)";
      break;
    case 'nostalgia':
      preview.style.filter = "brightness(122%) contrast(62%) saturate(155%) hue-rotate(13deg) sepia(15%) drop-shadow(0 0 2px #000)";
      break;
    default:
      preview.style.filter = "none";
  }
}

function resetarFoto() {
  preview.src = "";
  preview.style.display = "none";
  upload.value = "";
  preview.classList.remove("vhs-effect");
}

function baixarFoto() {
  if (!preview.src) return;

  canvas.width = preview.naturalWidth;
  canvas.height = preview.naturalHeight;

  ctx.filter = preview.style.filter;
  ctx.drawImage(preview, 0, 0);

  const nomeArquivo = "foto_" + Math.floor(Math.random() * 10000) + ".png";

  const link = document.createElement("a");
  link.download = nomeArquivo;
  link.href = canvas.toDataURL("image/png");
  link.click();
}
